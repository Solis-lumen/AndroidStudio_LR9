/*
package com.example.lr9

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.tween
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import androidx.compose.animation.core.Animatable

@Composable
fun TaskList(
    tasks: List<Task>,
    onToggleComplete: (Int, Boolean) -> Unit,
    onDelete: (Int) -> Unit
) {
    var visibleTasks = remember { mutableStateMapOf<Int, Boolean>() }

    tasks.forEach { task ->
        visibleTasks.putIfAbsent(task.id, true)
    }

    LazyColumn {
        items(tasks, key = { it.id }) {
            task -> val isVisible = visibleTasks[task.id] ?: true

            if (isVisible) {
                var offsetX by remember { mutableStateOf(0f) }
                //val coroutineScope = remember { Animatable(1f) }
                val coroutineScope = rememberCoroutineScope()
                val alpha = remember { Animatable(1f) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset { IntOffset(offsetX.toInt(), 0) }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onHorizontalDrag = { _, dragAmount ->
                                    offsetX += dragAmount
                                },
                                onDragEnd = {
                                    coroutineScope.launch {
                                        if (offsetX < -200) {
                                            alpha.animateTo(
                                                targetValue = 0f,
                                                animationSpec = tween(300)
                                            )
                                            visibleTasks[task.id] = false
                                            onDelete(task.id)
                                        } else {
                                            offsetX = 0f
                                        }
                                    }
                                }
                            )
                        }
                        .alpha(alpha.value)
                ) {
                    TaskItem(
                        task = task,
                        onToggleComplete = { isCompleted -> onToggleComplete(task.id, isCompleted) },
                        onDelete = {
                            visibleTasks[task.id] = false
                            onDelete(task.id)
                        }
                    )
                }
            }
        }
    }
}
*/






package com.example.lr9

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch

@Composable
fun TaskList(
    tasks: List<Task>,
    onToggleComplete: (Int, Boolean) -> Unit,
    onDelete: (Int) -> Unit
) {
    var visibleTasks = remember { mutableStateMapOf<Int, Boolean>() }

    tasks.forEach { task ->
        visibleTasks.putIfAbsent(task.id, true)
    }

    LazyColumn {
        items(tasks, key = { it.id }) { task ->
            val isVisible = visibleTasks[task.id] ?: true

            if (isVisible) {
                var offsetX by remember { mutableStateOf(0f) }
                val coroutineScope = rememberCoroutineScope()
                val alpha = remember { Animatable(1f) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset { IntOffset(offsetX.toInt(), 0) }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onHorizontalDrag = { _, dragAmount ->
                                    offsetX += dragAmount
                                },
                                onDragEnd = {
                                    coroutineScope.launch {
                                        if (offsetX < -200) {
                                            alpha.animateTo(
                                                targetValue = 0f,
                                                animationSpec = tween(300)
                                            )
                                            visibleTasks[task.id] = false
                                            onDelete(task.id)
                                        } else {
                                            offsetX = 0f
                                        }
                                    }
                                }
                            )
                        }
                        .alpha(alpha.value)
                ) {
                    AnimatedVisibility(
                        visible = isVisible,
                        exit = fadeOut(animationSpec = tween(1000))
                    ) {
                        TaskItem(
                            task = task,
                            onToggleComplete = { isCompleted -> onToggleComplete(task.id, isCompleted) },
                            onDelete = {
                                visibleTasks[task.id] = false
                                onDelete(task.id)
                            }
                        )
                    }
                }
            }
        }
    }
}
