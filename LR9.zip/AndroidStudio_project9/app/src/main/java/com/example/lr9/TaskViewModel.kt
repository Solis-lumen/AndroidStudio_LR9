package com.example.lr9

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

data class Task (
    val id: Int,
    val titleval : String,
    val details: String,
    var isCompleted: Boolean = false
)

class TaskViewModel : ViewModel() {
    private val _tasks = mutableStateListOf(
        Task(1, "Finish reading the book", "read 150 pages of \"Murder on the Orient Express\""),
        Task(2, "Organize files", "sort and categorize work documents"),
        Task(3, "Go for a run", "run 5 km around the park"),
        Task(4, "Prepare dinner", "cook pasta with vegetables for dinner"),
        Task(5, "Plan weekend trip", "search for places to visit this weekend"),
    )

    val tasks: List<Task> = _tasks

    val completedCount: Int
        get() = _tasks.count { it.isCompleted }

    fun toggleTaskCompletion(id: Int, isCompleted: Boolean) {
        val index = _tasks.indexOfFirst { it.id == id}
        if (index != -1) {
            _tasks[index] = _tasks[index].copy(isCompleted = isCompleted)
        }
    }

    fun deleteTask(id: Int) {
        _tasks.removeAll { it.id == id }
    }
}