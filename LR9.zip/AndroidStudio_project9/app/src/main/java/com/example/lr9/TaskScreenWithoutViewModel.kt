package com.example.lr9

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TaskScreenWithoutViewModel() {
    var tasks by rememberSaveable {
        mutableStateOf(
            listOf(
                Task(1, "Finish reading the book", "read 150 pages of \"Murder on the Orient Express\""),
                Task(2, "Organize files", "sort and categorize work documents"),
                Task(3, "Go for a run", "run 5 km around the park"),
                Task(4, "Prepare dinner", "cook pasta with vegetables for dinner"),
                Task(5, "Plan weekend trip", "search for places to visit this weekend"),
            )
        )
    }

    val completedCount = tasks.count { it.isCompleted }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Completed: ${completedCount}",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        TaskList(
            tasks = tasks,
            onToggleComplete = { id, isCompleted ->
                tasks = tasks.map {
                    if (it.id == id) it.copy(isCompleted = isCompleted) else it
                }
            },
            //onDelete = { id -> tasks.filterNot { it.id == id } }
            onDelete = { id -> tasks = tasks.filterNot { it.id == id } }
        )
    }
}