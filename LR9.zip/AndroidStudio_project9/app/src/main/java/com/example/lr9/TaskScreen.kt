package com.example.lr9

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TaskScreen(viewModel: TaskViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Completed: ${viewModel.completedCount}",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        TaskList(
            tasks = viewModel.tasks,
            onToggleComplete = { id, isCompleted -> viewModel.toggleTaskCompletion(id, isCompleted) },
            onDelete = { id -> viewModel.deleteTask(id) }
        )
    }
}